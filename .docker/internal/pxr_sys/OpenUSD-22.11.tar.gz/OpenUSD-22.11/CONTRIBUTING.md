Thank you for your interest in contributing to USD! We ask that
potential contributors review our guidelines on [contributing](http://openusd.org/docs/Contributing-to-USD.html) before submitting a pull request. 
