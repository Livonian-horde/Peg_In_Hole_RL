:orphan:

================
UsdSkel Examples
================

.. include:: dl_license.rst

.. raw:: html

   <center>
     <form method="get" action="https://graphics.pixar.com/usd/files/UsdSkelExamples.zip">
       <button type="submit">OK</button>
     </form>
   </center>
