.. div:: usd-tutorial-admonition

   :fa:`cogs` :ref:`Configure your Environment <tut_usd_tutorials:Environment Setup>`

   :fa:`check` Tested with `USD 22.11 <https://github.com/PixarAnimationStudios/USD/tree/v22.11>`_
