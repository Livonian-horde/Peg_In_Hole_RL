:orphan:

.. raw:: html
 
  <meta http-equiv="refresh" content="0;url=spec_usdpreviewsurface.html"/>

==========================
UsdPreviewSurface Proposal
==========================

This page has moved to :doc:`spec_usdpreviewsurface`
