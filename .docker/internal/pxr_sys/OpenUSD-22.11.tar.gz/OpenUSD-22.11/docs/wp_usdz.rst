:orphan:

.. raw:: html
 
  <meta http-equiv="refresh" content="0;url=spec_usdz.html"/>

==============================
Usdz File Format Specification
==============================

This page has moved to :doc:`spec_usdz`
